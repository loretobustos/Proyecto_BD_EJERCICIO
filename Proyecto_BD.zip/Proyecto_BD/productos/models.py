from django.db import models

class Producto(models.Model):
    nombre = models.TextField(max_length=100,null=False)
    marca = models.TextField(max_length=100,null=False)
    precio = models.IntegerField(null=False)